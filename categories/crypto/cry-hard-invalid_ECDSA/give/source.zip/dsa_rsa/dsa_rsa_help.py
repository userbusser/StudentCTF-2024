from Crypto.Util.number import bytes_to_long, long_to_bytes, inverse
from secret import p, q
from hashlib import sha512


class DSA_RSA():
    def __init__(self):
        self.p = p
        self.q = q
        assert len(bin(p)[2:]) == 1024 and len(bin(q)[2:]) == 1024
        self.N = p * q
        self.phi = (p-1)*(q-1)
        self.e = 65537
        self.d = inverse(self.e, self.phi)
    

    def sign(self, m: bytes) -> bytes:
        h = sha512(m).digest()
        m = bytes_to_long(h)
        r = pow(m, self.d, self.N)
        return long_to_bytes(r)


    def verify(self, m: bytes, r: bytes) -> bool:
        h = sha512(m).digest()
        r = bytes_to_long(r)
        m1 = pow(r, self.e, self.N)
        m1 = long_to_bytes(m1)
        return m1 == h
