from Crypto.Util.number import long_to_bytes, bytes_to_long, inverse, getRandomRange
from secret import private_key
from struct import pack, unpack
from hashlib import sha256


class Group(object):
    def __init__(self, p, g, n):
       self.p = p
       self.g = g
       self.n = n


class Curve(object):
    """ Класс эллиптической кривой """
    def __init__(self, a, b, field: Group):
        self.a = a
        self.b = b
        self.field = field


    def point_neg(self, point: None|list):
        if point is None:
            return None
        x, y = point
        result = [x, -y % self.field.p]
        return result


    def point_add(self, point1: None|list, point2: None|list):
        if point1 is None:
            return point2
        if point2 is None:
            return point1
        x1, y1 = point1
        x2, y2 = point2

        if x1 == x2 and y1 != y2:
            return None
        if x1 == x2:
            m = (3 * x1 * x1 + self.a) * inverse(2 * y1, self.field.p) % self.field.p
        else:
            m = (y1 - y2) * inverse(x1 - x2, self.field.p) % self.field.p
        x3 = m * m - x1 - x2
        y3 = y1 + m * (x3 - x1)
        result =[x3 % self.field.p,
                -y3 % self.field.p]
        return result


    def scalar_mult(self, k: int, point: None|list):
        if k < 0:
            return self.scalar_mult(-k, self.point_neg(point))
        result = None
        addend = point
        while k:
            if k & 1:
                result = self.point_add(result, addend)
            addend = self.point_add(addend, addend)
            k >>= 1
        return result


class ECDSA(object):
    def __init__(self, curve: Curve):
        self.curve = curve
        self.private_key = private_key
        assert len(bin(self.private_key)[2:]) == 256
        self.Q = self.curve.scalar_mult(self.private_key, self.curve.field.g)
    

    def sign(self, m: bytes):
        h = sha256(m).digest()
        h = bytes_to_long(h)
        r = 0
        while r == 0:
            k = getRandomRange(1, 2**71)
            r = self.curve.scalar_mult(k, self.curve.field.g)[0] % self.curve.field.n
        s = inverse(k, self.curve.field.n) * (h + self.private_key * r) % self.curve.field.n
        signature = (long_to_bytes(r), long_to_bytes(s))
        signature = b"".join([pack(">I", len(x)) + x for x in signature])
        return signature
        
    
    def verify(self, m: bytes, signature: bytes):
        h = sha256(m).digest()
        h = bytes_to_long(h)
        lenght_r = unpack(">I", signature[:4])[0]
        r = bytes_to_long(signature[4:4+lenght_r]) % self.curve.field.n
        s = bytes_to_long(signature[8+lenght_r:])  % self.curve.field.n
        if r == 0 or s ==0:
            return False
        w = inverse(s, self.curve.field.n)
        u1 = h * w % self.curve.field.n
        u2 = r * w % self.curve.field.n
        X = self.curve.point_add(self.curve.scalar_mult(u1, self.curve.field.g),
                                 self.curve.scalar_mult(u2, self.Q))
        v = X[0] 
        return v == r

