from flask import Flask, redirect ,make_response, request, render_template, url_for
from dsa_rsa.dsa_rsa_help import DSA_RSA
from ecdsa_.ecdsa_help import Group, Curve, ECDSA
from base64 import b64encode, b64decode
import json

app = Flask(__name__)

FLAG = open("FLAG.txt", "r").read()
# Parametrs Secp256r1
P = 0xffffffff00000001000000000000000000000000ffffffffffffffffffffffff
A = 0xffffffff00000001000000000000000000000000fffffffffffffffffffffffc
B = 0x5ac635d8aa3a93e7b3ebbd55769886bc651d06b0cc53b0f63bce3c3e27d2604b
N_secp_256 = 0xffffffff00000000ffffffffffffffffbce6faada7179e84f3b9cac2fc632551
Gx, Gy = 0x6b17d1f2e12c4247f8bce6e563a440f277037d812deb33a0f4a13945d898c296, 0x4fe342e2fe1a7f9b8ee7eb4a7c0f9e162bce33576b315ececbb6406837bf51f5
#----------------------------------------------------------------


def check_session_cookie(cookies):
    if "session" not in cookies:
        return redirect(url_for("sign", error="None session cookie in request"))
    if len(cookies.get('session').split(".")) != 3:
        return redirect(url_for("sign", error="None length session cookie"))
    array_cookie = cookies.get('session').split(".")
    try:
        array_cookie = [json.loads(b64decode(i)) for i in array_cookie[:2]] + [b64decode(array_cookie[2])]
    except Exception as e:
        return redirect(url_for("sign", error="None decode base64 session cookie"))
    type_data = array_cookie[0]
    if type_data.get("type") not in ["DSA_RSA", "ECDSA"]:
        return redirect(url_for("sign", error="None type sign"))
    return array_cookie


@app.route("/", methods = ['get', 'post'])
def start():
    return render_template("index.html", current_user=request.cookies.get('session'))


@app.route("/sign", methods = ['get', 'post'])
def sign():
    if request.method == "POST":
        if 'username' not in request.form:
            return render_template("sign.html", error="В запросе нет имени пользователя!")
        if 'password' not in request.form:
            return render_template("sign.html", error="В запросе отсутствует пароль!")
        username = request.form.get('username')
        if len(username) > 20 or len(username) == 0:
            return render_template("sign.html", error="Ошибка длины имени пользователя!")
        data = {"username": username, "is_vip": False}
        type_data = {"type": "DSA_RSA"}
        signature_data = DSA_RSA().sign(json.dumps(data).encode())
        cookie = b".".join([b64encode(json.dumps(type_data).encode()), 
                            b64encode(json.dumps(data).encode()), 
                            b64encode(signature_data)])
        
        result = make_response(redirect(url_for("affiche")))
        result.set_cookie("session", cookie.decode(), max_age=60 * 60 * 24 * 365)
        return result
    return render_template("sign.html")


@app.route("/ecdsa_sign", methods = ['get', 'post'])
def create_ecdsa_sign():
    array_cookie = check_session_cookie(request.cookies)
    if not isinstance(array_cookie, list):
        return array_cookie
    type_data, data, signature = array_cookie
    if not data.get("username"):
        return redirect(url_for("sign", error="None username in session"))
    if len(data.get("username")) > 20:
        return redirect(url_for("sign", error="Error length username"))
    if request.method == "POST":
        type_data = {"type": "ECDSA"}

        data = {"is_vip": False, "username": data.get("username")}
        if "curve_name" not in request.form:
            return render_template("ecdsa_sign.html", error= "Нет в запросе поля с названием ЭК!")
        if request.form.get("curve_name") == "custom":
            try:
                gx = int(request.form.get("gx"))
                gy = int(request.form.get("gy"))
            except:
                return render_template("ecdsa_sign.html", error= "Ошибка в координатах точки G!")
            G = (gx, gy)
            type_data["G"] = G
        else:
            G = (Gx, Gy)
        try:
            Curve_secp_256 = Curve(A, B, Group(P, G, N_secp_256))
            ecdsa_ = ECDSA(Curve_secp_256)
            signature_data = ecdsa_.sign(json.dumps(data).encode())
        except:
            return render_template("ecdsa_sign.html", error= "Ошибка в подписи ECDSA!")
        cookie = b".".join([b64encode(json.dumps(type_data).encode()), 
                            b64encode(json.dumps(data).encode()), 
                            b64encode(signature_data)])
        
        result = make_response(render_template("ecdsa_sign.html", error= "Поздравляем с усиленной подписью!"))
        result.set_cookie("session", cookie.decode(), max_age=60 * 60 * 24 * 365)
        return result
    return render_template("ecdsa_sign.html")


@app.route("/affiche")
def affiche():
    array_cookie = check_session_cookie(request.cookies)
    if not isinstance(array_cookie, list):
        return array_cookie
    return render_template("affiche.html")


@app.route("/vip")
def vip():
    array_cookie = check_session_cookie(request.cookies)
    if not isinstance(array_cookie, list):
        return array_cookie
    type_data, data, signature = array_cookie
    if type_data.get("type") == "DSA_RSA":
        if not DSA_RSA().verify(json.dumps(data).encode(), signature):
            return redirect(url_for("sign", error="None DSA_RSA verify"))
    else:
        G = (Gx, Gy)
        Curve_secp_256 = Curve(A, B, Group(P, G, N_secp_256))
        try:
            ecdsa_ = ECDSA(Curve_secp_256)    
            if not ecdsa_.verify(json.dumps(data).encode(), signature):
                return redirect(url_for("sign", error="None ECDSA verify"))
        except Exception:
            return redirect(url_for("sign", error="None valid ECDSA params"))
            
    if data.get("is_vip") is True:
        return render_template("vip.html", flag=FLAG)
    else:
        return redirect(url_for("start", error="Error vip status"))
        

@app.route("/logout")
def logout():
    res = make_response(redirect(url_for('sign')))
    res.set_cookie("session" , "" , max_age = 0)
    return res

if __name__ == "__main__":
    app.run("0.0.0.0", 1338)
