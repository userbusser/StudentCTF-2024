package main

import (
	"sync"
	"time"

	"gorm.io/driver/sqlite"
	"gorm.io/gorm"
)

var (
	db *gorm.DB
	mu sync.Mutex
)

func initDatabase() {
	var err error
	db, err = gorm.Open(sqlite.Open("shop.db"), &gorm.Config{})
	if err != nil {
		panic("failed to connect database")
	}

	db.AutoMigrate(&User{}, &Souvenir{}, &Coupon{}, &UserCoupon{}, &Purchase{})

	db.Create(&Souvenir{Name: "Flag Magnet", Price: 1337})
	db.Create(&Souvenir{Name: "Shopper bag", Price: 40})
	db.Create(&Souvenir{Name: "Fresh puffs", Price: 25})

	db.Create(&Coupon{Code: "StuD3n7_d1sC0uNt", Discount: 10})
}

func clearDatabase() {
	for {
		time.Sleep(10 * time.Minute)

		db.Exec("DELETE FROM purchases")
		db.Exec("DELETE FROM cart_items")
		db.Exec("DELETE FROM user_coupons")
		db.Exec("DELETE FROM coupons")
		db.Exec("DELETE FROM souvenirs")
		db.Exec("DELETE FROM users")

		db.Exec("DELETE FROM sqlite_sequence WHERE name IN ('purchases', 'cart_items', 'user_coupons', 'coupons', 'souvenirs', 'users')")

		println("Database fully cleaned at", time.Now().Format(time.RFC3339))
	}
}
