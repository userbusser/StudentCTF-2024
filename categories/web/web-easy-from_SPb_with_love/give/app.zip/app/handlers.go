package main

import (
	"encoding/json"
	"html/template"
	"net/http"
	"time"
)

func addToCartHandler(w http.ResponseWriter, r *http.Request) {
	userID, err := getUserIDFromCookie(r)
	if err != nil {
		w.WriteHeader(http.StatusUnauthorized)
		return
	}

	var input struct {
		ItemID uint `json:"itemId"`
	}
	json.NewDecoder(r.Body).Decode(&input)

	var souvenir Souvenir
	db.First(&souvenir, input.ItemID)

	if souvenir.ID != 0 {
		cart[userID] = append(cart[userID], CartItem{
			SouvenirID: souvenir.ID,
			UserID:     userID,
			Quantity:   1,
		})
		w.WriteHeader(http.StatusOK)
	} else {
		w.WriteHeader(http.StatusBadRequest)
	}

}

func removeFromCartHandler(w http.ResponseWriter, r *http.Request) {
	userID, err := getUserIDFromCookie(r)
	if err != nil {
		w.WriteHeader(http.StatusUnauthorized)
		return
	}

	var input struct {
		ItemID uint `json:"itemId"`
	}
	json.NewDecoder(r.Body).Decode(&input)

	mu.Lock()
	defer mu.Unlock()

	cartItems := cart[userID]
	for i, item := range cartItems {
		if item.SouvenirID == input.ItemID {

			cart[userID] = append(cartItems[:i], cartItems[i+1:]...)
			break
		}
	}

	w.WriteHeader(http.StatusOK)
}

func purchaseHistoryHandler(w http.ResponseWriter, r *http.Request) {
	userID, err := getUserIDFromCookie(r)
	if err != nil {
		w.WriteHeader(http.StatusUnauthorized)
		return
	}

	var purchases []Purchase
	result := db.Where("user_id = ?", userID).Find(&purchases)
	if result.Error != nil {
		http.Error(w, "Could not load purchase history", http.StatusInternalServerError)
		return
	}

	tmpl, err := template.ParseFiles("templates/purchase_history.html")
	if err != nil {
		http.Error(w, "Could not load template", http.StatusInternalServerError)
		return
	}

	err = tmpl.Execute(w, purchases)
	if err != nil {
		http.Error(w, "Could not render template", http.StatusInternalServerError)
	}
}

func cartItemsHandler(w http.ResponseWriter, r *http.Request) {
	userID, err := getUserIDFromCookie(r)
	if err != nil {
		w.WriteHeader(http.StatusUnauthorized)
		return
	}

	var items []struct {
		SouvenirID uint   `json:"SouvenirID"`
		Name       string `json:"Name"`
		Price      int    `json:"Price"`
	}

	for _, cartItem := range cart[userID] {
		var souvenir Souvenir
		db.First(&souvenir, cartItem.SouvenirID)
		if souvenir.ID != 0 {
			items = append(items, struct {
				SouvenirID uint   `json:"SouvenirID"`
				Name       string `json:"Name"`
				Price      int    `json:"Price"`
			}{
				SouvenirID: souvenir.ID,
				Name:       souvenir.Name,
				Price:      souvenir.Price,
			})
		}
	}

	json.NewEncoder(w).Encode(map[string]interface{}{
		"items": items,
	})
}

func checkoutHandler(w http.ResponseWriter, r *http.Request) {
	userID, err := getUserIDFromCookie(r)
	if err != nil {
		http.Error(w, "Unauthorized", http.StatusUnauthorized)
		return
	}

	var user User
	db.First(&user, userID)

	var total int
	for _, cartItem := range cart[userID] {
		var souvenir Souvenir
		db.First(&souvenir, cartItem.SouvenirID)
		total += souvenir.Price
	}

	if user.Balance >= total-user.Discount {
		user.Balance -= total - user.Discount
		db.Save(&user)

		var flagMessage string
		for _, cartItem := range cart[userID] {
			var souvenir Souvenir
			db.First(&souvenir, cartItem.SouvenirID)
			db.Create(&Purchase{
				UserID:       userID,
				SouvenirName: souvenir.Name,
				Price:        souvenir.Price,
				Quantity:     cartItem.Quantity,
				PurchaseDate: time.Now(),
			})

			if souvenir.Name == "Flag Magnet" {
				flagMessage = readFlagMessage()
				break
			}
		}

		cart[userID] = []CartItem{}
		response := map[string]interface{}{
			"message": "Checkout successful!",
		}
		if flagMessage != "" {
			response["flagText"] = flagMessage
		}

		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusOK)
		json.NewEncoder(w).Encode(response)
	} else {
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusBadRequest)
		json.NewEncoder(w).Encode(map[string]string{"message": "Insufficient balance"})
	}
}

func applyCouponHandler(w http.ResponseWriter, r *http.Request) {
	userID, err := getUserIDFromCookie(r)
	if err != nil {
		w.WriteHeader(http.StatusUnauthorized)
		return
	}

	var input struct {
		CouponCode string
	}
	json.NewDecoder(r.Body).Decode(&input)

	var coupon Coupon
	db.Where("code = ?", input.CouponCode).First(&coupon)

	if coupon.ID == 0 {
		w.WriteHeader(http.StatusBadRequest)
		return
	}

	var userCoupon UserCoupon
	db.Where("user_id = ? AND coupon_id = ?", userID, coupon.ID).First(&userCoupon)
	if userCoupon.ID != 0 {
		w.WriteHeader(http.StatusBadRequest)
		return
	}

	var user User
	db.First(&user, userID)

	var total int
	for _, cartItem := range cart[userID] {
		var souvenir Souvenir
		db.First(&souvenir, cartItem.SouvenirID)
		total += souvenir.Price
	}

	discountAmount := (total * coupon.Discount) / 100
	user.Discount += discountAmount
	db.Save(&user)

	db.Create(&UserCoupon{UserID: userID, CouponID: coupon.ID})

	json.NewEncoder(w).Encode(map[string]interface{}{
		"total": total - user.Discount,
	})
}

func balanceHandler(w http.ResponseWriter, r *http.Request) {
	userID, err := getUserIDFromCookie(r)
	if err != nil {
		w.WriteHeader(http.StatusUnauthorized)
		return
	}

	var user User
	db.First(&user, userID)

	json.NewEncoder(w).Encode(map[string]int{"balance": user.Balance})
}

func registerHandler(w http.ResponseWriter, r *http.Request) {
	var newUser User
	if err := json.NewDecoder(r.Body).Decode(&newUser); err != nil {
		http.Error(w, "Invalid request payload", http.StatusBadRequest)
		return
	}

	var existingUser User
	result := db.Where("username = ?", newUser.Username).First(&existingUser)
	if result.Error == nil {
		http.Error(w, "Username already taken", http.StatusConflict)
		return
	}

	newUser.Balance = 100
	if err := db.Create(&newUser).Error; err != nil {
		http.Error(w, "Failed to register user", http.StatusInternalServerError)
		return
	}

	w.WriteHeader(http.StatusCreated)
}

func loginHandler(w http.ResponseWriter, r *http.Request) {
	var input User
	json.NewDecoder(r.Body).Decode(&input)

	var user User
	db.Where("username =? AND password =?", input.Username, input.Password).First(&user)

	if user.ID != 0 {
		sessionID := generateSessionID()
		sessions.Lock()
		sessions.m[sessionID] = user.ID
		sessions.Unlock()

		http.SetCookie(w, &http.Cookie{
			Name:  "session_id",
			Value: sessionID,
			Path:  "/",
		})
		w.WriteHeader(http.StatusOK)
	} else {
		w.WriteHeader(http.StatusUnauthorized)
	}
}

func logoutHandler(w http.ResponseWriter, r *http.Request) {
	sessionID, err := r.Cookie("session_id")
	if err == nil {
		sessions.Lock()
		delete(sessions.m, sessionID.Value)
		sessions.Unlock()
	}

	http.SetCookie(w, &http.Cookie{
		Name:    "session_id",
		Value:   "",
		Expires: time.Unix(0, 0),
		Path:    "/",
	})
	w.Header().Set("Location", "/login")
	w.WriteHeader(http.StatusTemporaryRedirect)
}

func serveTemplate(templateName string) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		tmpl, err := template.ParseFiles("templates/" + templateName)
		if err != nil {
			http.Error(w, "Could not load template", http.StatusInternalServerError)
			return
		}
		tmpl.Execute(w, nil)
	}
}
