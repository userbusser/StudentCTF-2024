package main

import (
	"net/http"

	"github.com/gorilla/mux"
)

func main() {
	initDatabase()

	go clearDatabase()

	r := mux.NewRouter()

	fs := http.FileServer(http.Dir("./static"))
	r.PathPrefix("/static/").Handler(http.StripPrefix("/static/", fs))

	r.HandleFunc("/register", serveTemplate("register.html")).Methods("GET")
	r.HandleFunc("/login", serveTemplate("login.html")).Methods("GET")
	r.Handle("/", authMiddleware(serveTemplate("home.html"))).Methods("GET")
	r.Handle("/cart", authMiddleware(serveTemplate("cart.html"))).Methods("GET")

	r.HandleFunc("/register", registerHandler).Methods("POST")
	r.HandleFunc("/login", loginHandler).Methods("POST")
	r.HandleFunc("/logout", logoutHandler).Methods("GET")
	r.HandleFunc("/add-to-cart", addToCartHandler).Methods("POST")
	r.HandleFunc("/cart-items", cartItemsHandler).Methods("GET")
	r.HandleFunc("/apply-coupon", applyCouponHandler).Methods("POST")
	r.HandleFunc("/checkout", checkoutHandler).Methods("POST")
	r.HandleFunc("/remove-from-cart", removeFromCartHandler).Methods("POST")
	r.HandleFunc("/balance", balanceHandler).Methods("GET")
	r.HandleFunc("/purchase-history", purchaseHistoryHandler).Methods("GET")

	http.ListenAndServe(":8081", r)
}
