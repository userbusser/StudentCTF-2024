package main

import (
	"time"

	"gorm.io/gorm"
)

type User struct {
	gorm.Model
	Username string
	Password string
	Balance  int
	Discount int
}

type Souvenir struct {
	gorm.Model
	Name  string
	Price int
}

type UserCoupon struct {
	gorm.Model
	UserID   uint
	CouponID uint
}

type Coupon struct {
	gorm.Model
	Code     string
	Discount int
}

type CartItem struct {
	SouvenirID uint
	UserID     uint
	Quantity   int
}

type Purchase struct {
	ID           uint
	UserID       uint
	SouvenirName string
	Price        int
	Quantity     int
	PurchaseDate time.Time
}

var cart = map[uint][]CartItem{}