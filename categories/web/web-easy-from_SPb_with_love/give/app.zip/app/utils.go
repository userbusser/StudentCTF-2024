package main

import (
	"crypto/rand"
	"encoding/hex"
	"net/http"
	"os"
	"sync"
)

var sessions = struct {
	sync.RWMutex
	m map[string]uint
}{m: make(map[string]uint)}

func getUserIDFromCookie(r *http.Request) (uint, error) {
	cookie, err := r.Cookie("session_id")
	if err != nil {
		return 0, err
	}

	sessions.RLock()
	userID, ok := sessions.m[cookie.Value]
	sessions.RUnlock()

	if !ok {
		return 0, http.ErrNoCookie
	}
	return userID, nil
}

func generateSessionID() string {
	b := make([]byte, 16)
	_, err := rand.Read(b)
	if err != nil {
		panic(err)
	}
	return hex.EncodeToString(b)
}

func readFlagMessage() string {
	data, err := os.ReadFile("flag.txt")
	if err != nil {
		return "Congratulations on purchasing the Flag Magnet!"
	}
	return string(data)
}
